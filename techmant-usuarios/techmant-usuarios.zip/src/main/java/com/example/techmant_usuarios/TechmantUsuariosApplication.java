package com.example.techmant_usuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechmantUsuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechmantUsuariosApplication.class, args);
	}

}
