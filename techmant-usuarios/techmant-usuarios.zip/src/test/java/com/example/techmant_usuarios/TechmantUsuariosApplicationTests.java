package com.example.techmant_usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechmantUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
